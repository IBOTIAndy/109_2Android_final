package com.bot.final_project_2021;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AddIoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_io);
    }
}